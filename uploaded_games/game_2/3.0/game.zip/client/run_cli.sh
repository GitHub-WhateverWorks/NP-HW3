#!/bin/bash
HERE="$(dirname "$(readlink -f "$0")")"

export LD_LIBRARY_PATH="$HERE/lib:$LD_LIBRARY_PATH"

exec "$HERE/game_client_cli" "$@"
